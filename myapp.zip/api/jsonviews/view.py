from rest_framework.decorators import api_view

@api_view(['POST'])
def Class_Model_Json_handle(request):
    pass
    




