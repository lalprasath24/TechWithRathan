from django.urls import path,include
from . import views
from api.jsonviews import view as jsonview
from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)
# router = DefaultRouter()
# router.register('employees',views.EmployeeViewSet,basename='employee')


urlpatterns = [
    path('students/',views.StudentView),
    path('students/<int:pk>',views.StudentDetailsView),
    
    path('employees/',views.Employees.as_view()),
    path('employees/<int:pk>',views.EmployeeDetails.as_view()),
    # path('', include(router.urls))
    path('jsonHandling/',views.JsonHandling),
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('hello/',views.HelloView.as_view()),
    
]