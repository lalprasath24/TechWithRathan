from rest_framework.response import Response
from rest_framework import status,mixins,generics,viewsets
from rest_framework.decorators import api_view
from students.models import student
from .serializers import StudentSerializer,EmployeeSerializer
from rest_framework.views import APIView
from employee.models import Employee
from django.http import Http404,JsonResponse
from django.shortcuts import get_object_or_404
import json 
from rest_framework.permissions import IsAuthenticated

@api_view(['GET','POST'])
def StudentView(request):
    if request.method == 'GET':
        students = student.objects.all()
        serilizer_students = StudentSerializer(students,many=True)
        return Response(serilizer_students.data,status=status.HTTP_200_OK)
    elif request.method == 'POST':
        serilizer = StudentSerializer(data = request.data)
        if serilizer.is_valid():
            serilizer.save()
            return Response(serilizer.data,status=status.HTTP_201_CREATED)
        return Response(serilizer.data,status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET','PUT','DELETE'])
def StudentDetailsView(request,pk):
    try:
        studentObj = student.objects.get(pk=pk)
    except student.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)
            
    if request.method == 'GET':        
        seri_students = StudentSerializer(studentObj)
        return Response(seri_students.data,status=status.HTTP_200_OK)
    elif request.method == 'PUT':
        serilizer = StudentSerializer(studentObj,data =request.data)
        if serilizer.is_valid():
            serilizer.save()
            return Response(serilizer.data,status=status.HTTP_200_OK)
        else:
            return Response(serilizer.errors,status=status.HTTP_400_BAD_REQUEST)    
    elif request.method == 'DELETE':
        studentObj.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)    



class Employees(APIView):
    def get(self,request):
        employees =Employee.objects.all()
        emp_data = EmployeeSerializer(employees,many=True)
        return Response(emp_data.data,status=status.HTTP_200_OK)       
        
    def post(self,request):
        serilizer = EmployeeSerializer(data =request.data)
        if serilizer.is_valid():
            serilizer.save()
            return Response(serilizer.data,status=status.HTTP_200_OK)
        return Response(serilizer.errors,status=status.HTTP_400_BAD_REQUEST)


class EmployeeDetails(APIView):
    
    def get_object(self,pk):
        try:
            return Employee.objects.get(pk=pk)
        except Employee.DoesNotExist:
            return Http404
        
    def get(self,request,pk):
        emp_obj =  self.get_object(pk)
        seriliaze = EmployeeSerializer(emp_obj)
        return Response(seriliaze.data,status=status.HTTP_200_OK)
    
    def put(self,request,pk):
        emp_obj =  self.get_object(pk)
        put_serilizer = EmployeeSerializer(emp_obj,data=request.data)
        if put_serilizer.is_valid():
            put_serilizer.save()
            return Response(put_serilizer.data,status=status.HTTP_200_OK)
        return Response(put_serilizer.errors,status=status.HTTP_400_BAD_REQUEST)
    
    def delete(self,requst,pk):
        emp_obj = self.get_object(pk)
        emp_obj.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
                

# Mixins        

"""      
class Employees(mixins.ListModelMixin,mixins.CreateModelMixin,generics.GenericAPIView):
    queryset = Employee.objects.all()
    serializer_class = EmployeeSerializer
    
    def get(self,request):
        return self.list(request)
    def post(self,request):
        return self.create(request)                            
    
class EmployeeDetails(mixins.RetrieveModelMixin,mixins.UpdateModelMixin,mixins.DestroyModelMixin,generics.GenericAPIView): 
    queryset = Employee.objects.all()
    serializer_class = EmployeeSerializer
    
    def get(self,request,pk):
        return self.retrieve(request,pk)
    def put(self,request,pk):
        return self.update(request,pk)
    def delete(self,request,pk):
        return self.destroy(request,pk)   
"""

# Generics
"""
class Employees(generics.ListCreateAPIView):
    queryset = Employee.objects.all()
    serializer_class = EmployeeSerializer
    
class EmployeeDetails(generics.RetrieveUpdateDestroyAPIView):
    queryset = Employee.objects.all()
    serializer_class = EmployeeSerializer
    lookup_field= 'pk'


"""         
#viewsets 

"""
class EmployeeViewSet(viewsets.ViewSet):
    def list(self, request):
        emp_obj = Employee.objects.all()
        serializer = EmployeeSerializer(emp_obj, many=True)
        return Response(data=serializer.data, status=status.HTTP_200_OK)

    def create(self, request):
        serializer = EmployeeSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(data=serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def retrieve(self, request, pk=None):
        emp_obj = get_object_or_404(Employee, pk=pk)
        serializer = EmployeeSerializer(emp_obj)
        return Response(data=serializer.data, status=status.HTTP_200_OK)

    def update(self, request, pk=None):
        emp_obj = get_object_or_404(Employee, pk=pk)
        serializer = EmployeeSerializer(emp_obj, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(data=serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def destroy(self, request, pk=None):
        emp_obj = get_object_or_404(Employee, pk=pk)
        emp_obj.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
        
        
class EmployeeViewSet(viewsets.ModelViewSet):
    queryset = Employee.objects.all()
    serializer_class = EmployeeSerializer       
        
"""                   
                  
@api_view(['POST'])
def JsonHandling(request):
    data = request.data.get('data', [])

    if not data:
        return Response({'error': 'No data found'}, status=400)

    account = data[0]  # First account
    account_id = account.get('id')
    account_name = account.get('name')

    # Owner details
    owner = account.get('details', {}).get('owner', {})
    firstname = owner.get('firstname')
    lastname = owner.get('lastname')
    email = owner.get('email')

    # Billing details
    billing = account.get('details', {}).get('billing', {})
    currency = billing.get('currency')
    threshold = billing.get('threshold')
    spent = billing.get('spent')

    # Services and resources
    services = account.get('services', [])
    service_data = []

    for service in services:
        service_id = service.get('service_id')
        service_name = service.get('service_name')
        resources = service.get('resources', [])

        resource_list = []
        for resource in resources:
            resource_list.append({
                'resource_id': resource.get('resource_id'),
                'type': resource.get('type'),
                'status': resource.get('status'),
                'cost': resource.get('cost')
            })

        service_data.append({
            'service_id': service_id,
            'service_name': service_name,
            'resources': resource_list
        })

    return Response({
        'account_id': account_id,
        'account_name': account_name,
        'owner': {
            'firstname': firstname,
            'lastname': lastname,
            'email': email
        },
        'billing': {
            'currency': currency,
            'threshold': threshold,
            'spent': spent
        },
        'services': service_data
    })


class HelloView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        return Response({'message': f'Hello, {request.user.username}!'})